# Dilkas Meraj Prediction King 👑

## Files
- index.html — main website
- style.css — design and responsive layout

## How to customize
1. Open `index.html`.
2. Replace the Instagram URL `https://instagram.com/` with your real Instagram profile URL.
3. Replace the Telegram URL `https://t.me/` with your real Telegram channel URL.
4. Replace `your-email@example.com` with your email.
5. Upload both files to your hosting's public folder.

## Important
The prediction content is presented for entertainment/informational purposes. No prediction is guaranteed.
